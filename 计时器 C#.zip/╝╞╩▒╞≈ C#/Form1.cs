﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//author：Hsyl007
//date：2018.8


namespace JSQ
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }
        float  time = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            time = 0;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time++;
            //decimal mm = (decimal)((decimal)time/(decimal) 60);
            //label5.Text = Convert.ToInt32(Math.Ceiling(mm)).ToString();
            int  h = (int)time / 60;
            float  m = time%60;
            if (h <= 9)
            {
                label3.Text = "0" + h.ToString();
            }
            else
            {
                label3.Text = h.ToString();
            }
            if (m <= 9)
            {
                label4.Text ="0"+ m.ToString();
            }
            else
            {
                label4.Text = m.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            history.Items.Add(label3.Text + "秒" + label4.Text );
            //if(9<l&&l<12)
            highscores.Items.Add(label3.Text + "秒" + label4.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            time = 0;
            label3.Text ="00";
            label4.Text = "00";
            timer1.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void 清除记录ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            history.Items.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void highscores_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
